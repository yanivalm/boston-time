# Time Clock MVP

This project is a minimal prototype for an Israeli time clock system with geofencing and overtime calculations.

## Structure

- **backend/** — FastAPI service with a calculation endpoint (`/calc/day`) and an example calculation module.
- **frontend/** — Minimal PWA placeholder.
- **README.md** — Project overview.

## Running

To run the backend locally:

```bash
cd backend
pip install -r requirements.txt
uvicorn main:app --reload
```

Then navigate to http://localhost:8000/docs to explore the API.
