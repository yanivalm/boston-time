// Service worker placeholder
self.addEventListener('install', (event) => {
  console.log('Service worker installed');
});
